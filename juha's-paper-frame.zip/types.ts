export type OutputSize = 1200 | 800 | 400;
export type OutputFormat = 'webp' | 'jpeg' | 'png';
export type TitleColor = 'orange' | 'brown' | 'navy' | 'pink' | 'black';
